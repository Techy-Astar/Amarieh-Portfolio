import { supabase, type Profile } from './supabase';

const ACTIVE_KEY = 'heyborhood:profile_id';
const ACCOUNTS_KEY = 'heyborhood:profile_ids';

export function getStoredProfileId(): string | null {
  try {
    return localStorage.getItem(ACTIVE_KEY);
  } catch {
    return null;
  }
}

function setActiveProfileId(id: string): void {
  try {
    localStorage.setItem(ACTIVE_KEY, id);
  } catch {
    // localStorage may be unavailable (private mode) — non-fatal
  }
}

export function getStoredProfileIds(): string[] {
  try {
    const raw = localStorage.getItem(ACCOUNTS_KEY);
    if (!raw) return [];
    const ids = JSON.parse(raw) as string[];
    return Array.isArray(ids) ? ids : [];
  } catch {
    return [];
  }
}

function persistProfileIds(ids: string[]): void {
  try {
    localStorage.setItem(ACCOUNTS_KEY, JSON.stringify(ids));
  } catch {
    // non-fatal
  }
}

function addStoredProfileId(id: string): void {
  const ids = getStoredProfileIds();
  if (!ids.includes(id)) {
    ids.push(id);
    persistProfileIds(ids);
  }
  setActiveProfileId(id);
}

export function clearStoredProfileId(): void {
  try {
    localStorage.removeItem(ACTIVE_KEY);
    localStorage.removeItem(ACCOUNTS_KEY);
  } catch {
    // non-fatal
  }
}

export function switchStoredProfileId(id: string): void {
  setActiveProfileId(id);
}

export async function createProfile(input: {
  name: string;
  age?: number | null;
  is_guest: boolean;
}): Promise<Profile> {
  const { data, error } = await supabase
    .from('profiles')
    .insert({
      name: input.name.trim(),
      age: input.age ?? null,
      is_guest: input.is_guest,
    })
    .select()
    .single();

  if (error) {
    throw new Error(error.message);
  }
  addStoredProfileId(data.id);
  return data;
}

export async function fetchProfile(id: string): Promise<Profile | null> {
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .eq('id', id)
    .maybeSingle();

  if (error) {
    throw new Error(error.message);
  }
  return data;
}

export async function fetchProfiles(ids: string[]): Promise<Profile[]> {
  if (ids.length === 0) return [];
  const { data, error } = await supabase
    .from('profiles')
    .select('*')
    .in('id', ids);

  if (error) {
    throw new Error(error.message);
  }
  return data ?? [];
}

export async function updateProfile(
  id: string,
  input: Partial<Pick<Profile, 'name' | 'age' | 'avatar_url' | 'preferred_activities' | 'is_guest'>>
): Promise<Profile> {
  const { data, error } = await supabase
    .from('profiles')
    .update({ ...input, updated_at: new Date().toISOString() })
    .eq('id', id)
    .select()
    .single();

  if (error) {
    throw new Error(error.message);
  }
  return data;
}
