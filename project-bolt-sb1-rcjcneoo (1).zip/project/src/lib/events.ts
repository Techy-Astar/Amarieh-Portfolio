import { supabase, type Event, type AgeGroup } from './supabase';

export async function fetchEventsByAge(ageGroup: AgeGroup): Promise<Event[]> {
  const { data, error } = await supabase
    .from('events')
    .select('*')
    .eq('age_group', ageGroup)
    .order('date', { ascending: true });

  if (error) {
    throw new Error(error.message);
  }
  return data ?? [];
}

export async function fetchEventById(id: string): Promise<Event | null> {
  const { data, error } = await supabase
    .from('events')
    .select('*')
    .eq('id', id)
    .maybeSingle();

  if (error) {
    throw new Error(error.message);
  }
  return data;
}

export async function createEvent(
  input: Omit<Event, 'id' | 'created_at' | 'created_by'> & { created_by?: string | null }
): Promise<Event> {
  const { data, error } = await supabase
    .from('events')
    .insert(input)
    .select()
    .single();

  if (error) {
    throw new Error(error.message);
  }
  return data;
}

export async function deleteEvent(id: string): Promise<void> {
  const { error } = await supabase.from('events').delete().eq('id', id);
  if (error) {
    throw new Error(error.message);
  }
}

export function parsePrice(price: string | null): number {
  if (!price) return 0;
  const match = price.match(/(\d+(?:\.\d+)?)/);
  if (!match) return 0; // "Free", empty, or text with no digits
  return parseFloat(match[1]);
}
