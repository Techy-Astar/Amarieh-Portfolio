import { useState } from 'react';
import { Sparkles, User, UserCheck, ArrowRight, Loader2, AlertCircle } from 'lucide-react';
import { createProfile } from '../lib/profiles';
import type { Profile } from '../lib/supabase';

interface SignUpViewProps {
  onComplete: (profile: Profile) => void;
}

export default function SignUpView({ onComplete }: SignUpViewProps) {
  const [name, setName] = useState('');
  const [age, setAge] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = name.trim();
    if (!trimmed) {
      setError('Please enter your name so we can welcome you.');
      return;
    }
    setSubmitting(true);
    setError(null);
    try {
      const ageNum = age.trim() ? parseInt(age, 10) : null;
      const profile = await createProfile({
        name: trimmed,
        age: ageNum && !isNaN(ageNum) ? ageNum : null,
        is_guest: false,
      });
      onComplete(profile);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  const handleGuest = async () => {
    setSubmitting(true);
    setError(null);
    try {
      const profile = await createProfile({ name: 'Guest', is_guest: true });
      onComplete(profile);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Something went wrong. Please try again.');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 font-nunito">
      <div className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900" />
        <div
          className="absolute inset-0 opacity-20"
          style={{
            backgroundImage:
              'radial-gradient(circle at 20% 20%, #60a5fa 0, transparent 40%), radial-gradient(circle at 80% 60%, #34d399 0, transparent 40%), radial-gradient(circle at 50% 100%, #fb923c 0, transparent 40%)',
          }}
        />
        <div className="relative max-w-6xl mx-auto px-6 pt-16 pb-24 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/10 backdrop-blur border border-white/15 text-white/90 text-sm font-medium mb-6">
            <Sparkles className="w-4 h-4" />
            Welcome to the neighborhood
          </div>
          <h1 className="text-5xl md:text-7xl font-bold text-white tracking-tight leading-tight">
            Heyborhood
          </h1>
          <p className="mt-4 text-lg md:text-xl text-white/70 max-w-2xl mx-auto">
            Let's get to know you first. Tell us a little about yourself, or jump in as a guest.
          </p>
        </div>
      </div>

      <div className="max-w-5xl mx-auto px-6 -mt-16 pb-20 relative">
        <div className="grid md:grid-cols-2 gap-6">

          {/* Sign-up form card */}
          <div className="rounded-3xl bg-white shadow-xl overflow-hidden">
            <div className="h-2 bg-gradient-to-r from-blue-500 via-emerald-400 to-amber-400" />
            <div className="p-7">
              <div className="flex items-center gap-3 mb-1">
                <div className="w-10 h-10 rounded-xl bg-blue-50 flex items-center justify-center text-blue-600">
                  <UserCheck className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-slate-900">Create your profile</h2>
                  <p className="text-sm text-slate-500">Just a name and age — that's it.</p>
                </div>
              </div>

              <form onSubmit={handleSubmit} className="mt-6 space-y-5">
                <label className="block">
                  <span className="text-sm font-semibold text-slate-700 mb-1.5 block">
                    Your name <span className="text-red-500">*</span>
                  </span>
                  <input
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-blue-300 focus:border-transparent transition-all placeholder:text-slate-400"
                    placeholder="e.g. Amarieh"
                    required
                    autoFocus
                  />
                </label>

                <label className="block">
                  <span className="text-sm font-semibold text-slate-700 mb-1.5 block">
                    Your age
                  </span>
                  <input
                    type="number"
                    min="1"
                    max="120"
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 bg-white text-slate-900 text-sm focus:outline-none focus:ring-2 focus:ring-blue-300 focus:border-transparent transition-all placeholder:text-slate-400"
                    placeholder="Optional"
                  />
                </label>

                {error && (
                  <div className="rounded-xl bg-red-50 border border-red-200 p-3 flex items-start gap-2 text-red-700 text-sm">
                    <AlertCircle className="w-4 h-4 mt-0.5 flex-shrink-0" />
                    {error}
                  </div>
                )}

                <button
                  type="submit"
                  disabled={submitting}
                  className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 rounded-full bg-slate-900 text-white font-semibold text-sm hover:bg-slate-800 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {submitting ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" /> Setting up...
                    </>
                  ) : (
                    <>
                      Start exploring <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </form>
            </div>
          </div>

          {/* Guest card */}
          <div className="rounded-3xl bg-white shadow-xl overflow-hidden">
            <div className="h-2 bg-gradient-to-r from-amber-400 via-rose-400 to-emerald-400" />
            <div className="p-7 flex flex-col h-full">
              <div className="flex items-center gap-3 mb-1">
                <div className="w-10 h-10 rounded-xl bg-amber-50 flex items-center justify-center text-amber-600">
                  <User className="w-5 h-5" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-slate-900">Continue as guest</h2>
                  <p className="text-sm text-slate-500">Skip the form and browse right away.</p>
                </div>
              </div>

              <p className="mt-6 text-slate-600 text-sm leading-relaxed">
                Not ready to share details? No problem. You can jump straight into the events and
                explore everything Heyborhood has to offer. You can always set up a profile later.
              </p>

              <div className="mt-auto pt-8">
                <button
                  onClick={handleGuest}
                  disabled={submitting}
                  className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 rounded-full border border-slate-300 text-slate-800 font-semibold text-sm hover:bg-slate-50 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {submitting ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" /> Loading...
                    </>
                  ) : (
                    <>
                      Explore as guest <ArrowRight className="w-4 h-4" />
                    </>
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>

        <p className="mt-8 text-center text-slate-400 text-sm">
          Your information stays on your device. We use it only to personalize your Heyborhood experience.
        </p>
      </div>
    </div>
  );
}
