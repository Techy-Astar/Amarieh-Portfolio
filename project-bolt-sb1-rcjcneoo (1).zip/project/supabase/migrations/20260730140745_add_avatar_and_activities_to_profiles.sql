/*
# Extend profiles with avatar and preferred activities

## Purpose
Support the new profile page where a user can add a profile picture and pick
the activities they're most interested in. These fields are optional and
nullable so existing guest profiles are unaffected.

## Modified Tables
### profiles
- Added `avatar_url` (text, nullable) — URL of the user's profile picture.
  Stored as a URL (we use stock photo URLs / user-provided URLs); no binary
  upload pipeline in this app.
- Added `preferred_activities` (text[], nullable) — list of activity tags the
  user is interested in, e.g. {"Sports","Music","Arts"}. Uses a native
  PostgreSQL text array so it can be queried/filtered later.

## Security
- No RLS policy changes. The profiles table remains publicly readable/writable
  via anon + authenticated (no-auth community app). The new columns carry no
  sensitive data (no email / password / contact info).

## Notes
- Uses a DO $$ block so re-running is safe (columns are only added if missing).
- No data is lost: both columns are nullable and added with no default.
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'avatar_url'
  ) THEN
    ALTER TABLE profiles ADD COLUMN avatar_url text;
  END IF;

  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'profiles' AND column_name = 'preferred_activities'
  ) THEN
    ALTER TABLE profiles ADD COLUMN preferred_activities text[];
  END IF;
END $$;
