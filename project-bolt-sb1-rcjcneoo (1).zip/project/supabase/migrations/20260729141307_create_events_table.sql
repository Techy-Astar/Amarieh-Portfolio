/*
# Create events table for Heyborhood

## Purpose
Stores community events filtered by age group for the Heyborhood neighborhood events platform.

## New Tables

### events
- `id` (uuid, primary key) — unique identifier
- `title` (text, not null) — event name
- `description` (text) — event details
- `age_group` (text, not null) — one of: 'kids', 'teens', 'adults'
- `date` (date, not null) — event date
- `time` (text) — formatted time string (e.g. "2:00 PM")
- `location` (text, not null) — venue or address
- `image_url` (text) — event cover image
- `category` (text) — type of event (sports, arts, music, etc.)
- `price` (text) — free or cost info
- `created_at` (timestamptz) — record creation timestamp

## Security
- RLS enabled on events table
- Public read/write via anon + authenticated (no sign-in required app)

## Notes
- Seed data included for each age group so the app is immediately useful
- age_group column uses a check constraint to enforce valid values
*/

CREATE TABLE IF NOT EXISTS events (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  age_group text NOT NULL CHECK (age_group IN ('kids', 'teens', 'adults')),
  date date NOT NULL,
  time text,
  location text NOT NULL,
  image_url text,
  category text,
  price text DEFAULT 'Free',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE events ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_events" ON events;
CREATE POLICY "anon_select_events" ON events FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_events" ON events;
CREATE POLICY "anon_insert_events" ON events FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_events" ON events;
CREATE POLICY "anon_update_events" ON events FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_events" ON events;
CREATE POLICY "anon_delete_events" ON events FOR DELETE
  TO anon, authenticated USING (true);

-- Seed: Kids events
INSERT INTO events (title, description, age_group, date, time, location, image_url, category, price) VALUES
(
  'Kids Paint & Play Day',
  'Join us for a fun afternoon of painting, drawing, and creative expression! All supplies provided. Perfect for kids who love to get messy and make art.',
  'kids',
  CURRENT_DATE + INTERVAL '3 days',
  '10:00 AM',
  'Riverside Community Center',
  'https://images.pexels.com/photos/5274605/pexels-photo-5274605.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'Arts & Crafts',
  'Free'
),
(
  'Summer Splash Pool Party',
  'Cool off this summer at our annual kids pool party! Games, prizes, and refreshments included. Life guards on duty. Ages 3-10.',
  'kids',
  CURRENT_DATE + INTERVAL '7 days',
  '1:00 PM',
  'Maplewood Aquatic Center',
  'https://images.pexels.com/photos/27788084/pexels-photo-27788084.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'Recreation',
  '$5 entry'
),
(
  'Junior Soccer Camp',
  'Learn the basics of soccer with certified youth coaches. Drills, scrimmages, and teamwork building. Bring cleats and water bottle.',
  'kids',
  CURRENT_DATE + INTERVAL '5 days',
  '9:00 AM',
  'Green Acres Sports Field',
  'https://images.pexels.com/photos/9438088/pexels-photo-9438088.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'Sports',
  '$10'
),
(
  'Birthday Bash Bonanza',
  'A mega birthday party open to all kids! Balloon animals, face painting, bounce houses, and a giant cake. Come celebrate with the community.',
  'kids',
  CURRENT_DATE + INTERVAL '10 days',
  '11:00 AM',
  'Sunnydale Park Pavilion',
  'https://images.pexels.com/photos/7155966/pexels-photo-7155966.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'Party',
  'Free'
),
(
  'Science Explorers Workshop',
  'Hands-on experiments and STEM activities designed for curious young minds. Learn about chemistry, physics, and biology through play.',
  'kids',
  CURRENT_DATE + INTERVAL '12 days',
  '2:00 PM',
  'City Science Museum — Youth Wing',
  'https://images.pexels.com/photos/12574462/pexels-photo-12574462.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'Education',
  '$8'
),
(
  'Storytime in the Park',
  'Bring a blanket and enjoy an afternoon of read-alouds, songs, and puppetry performed by local librarians. All ages welcome!',
  'kids',
  CURRENT_DATE + INTERVAL '2 days',
  '4:00 PM',
  'Oak Street Park, Main Gazebo',
  'https://images.pexels.com/photos/7155950/pexels-photo-7155950.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'Culture',
  'Free'
),

-- Seed: Teens events
(
  'Teen Night Live',
  'A live music showcase featuring local teen bands and solo artists. Doors open at 6 PM. Bring friends and support local talent in a safe, alcohol-free venue.',
  'teens',
  CURRENT_DATE + INTERVAL '4 days',
  '6:00 PM',
  'The Spot Youth Venue',
  'https://images.pexels.com/photos/4218027/pexels-photo-4218027.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'Music',
  '$5 at door'
),
(
  'Summer Skate Jam',
  'Show off your tricks at our monthly skate competition. Open to all skill levels. Prizes for best trick, best run, and most creative style.',
  'teens',
  CURRENT_DATE + INTERVAL '6 days',
  '3:00 PM',
  'Westside Skate Park',
  'https://images.pexels.com/photos/11555609/pexels-photo-11555609.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'Sports',
  'Free'
),
(
  'Teen Art & Social',
  'Mix, mingle, and make art with other teens from the neighborhood. All mediums welcome — painting, sketching, digital art, and more.',
  'teens',
  CURRENT_DATE + INTERVAL '8 days',
  '5:00 PM',
  'Youth Arts Collective Studio',
  'https://images.pexels.com/photos/7243966/pexels-photo-7243966.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'Arts & Crafts',
  'Free'
),
(
  'Community Basketball Tournament',
  '3-on-3 basketball tournament open to teens 13–18. Register a team or join as an individual and get paired up. Trophies and gift cards for winners.',
  'teens',
  CURRENT_DATE + INTERVAL '9 days',
  '10:00 AM',
  'Downtown Recreation Complex',
  'https://images.pexels.com/photos/31658152/pexels-photo-31658152.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'Sports',
  'Free'
),
(
  'Teen Film Fest Screening',
  'Short films created by teens from across the city. Vote for your favorites and hear the directors talk about their creative process.',
  'teens',
  CURRENT_DATE + INTERVAL '11 days',
  '7:00 PM',
  'Harmon Street Theater',
  'https://images.pexels.com/photos/1238965/pexels-photo-1238965.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'Culture',
  '$3'
),
(
  'Youth Orchestra Showcase',
  'Watch the award-winning City Youth Orchestra perform classical and contemporary pieces. A night of outstanding musicianship by teens 14–18.',
  'teens',
  CURRENT_DATE + INTERVAL '14 days',
  '6:30 PM',
  'Parkview Amphitheater',
  'https://images.pexels.com/photos/32543377/pexels-photo-32543377.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'Music',
  'Free'
),

-- Seed: Adults events
(
  'Friday Night Happy Hour',
  'Kick off the weekend with craft cocktails, live music from local jazz musicians, and a rotating menu of small bites. 21+ only.',
  'adults',
  CURRENT_DATE + INTERVAL '1 day',
  '6:00 PM',
  'The Rooftop Lounge, 5th & Main',
  'https://images.pexels.com/photos/9566257/pexels-photo-9566257.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'Nightlife',
  'Free entry'
),
(
  'Community Volleyball Day',
  'All-day open volleyball tournament for adults 18+. Mixed and competitive divisions available. Register solo or as a team of 4.',
  'adults',
  CURRENT_DATE + INTERVAL '5 days',
  '9:00 AM',
  'Beachside Recreation Fields',
  'https://images.pexels.com/photos/30747154/pexels-photo-30747154.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'Sports',
  '$15/team'
),
(
  'Wine & Canvas Night',
  'Guided painting class with a glass of wine included. No experience necessary! Follow along with a local artist to create your own masterpiece.',
  'adults',
  CURRENT_DATE + INTERVAL '3 days',
  '7:00 PM',
  'Studio Eleven Art Space',
  'https://images.pexels.com/photos/6174000/pexels-photo-6174000.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'Arts & Crafts',
  '$35'
),
(
  'Friends & Cocktails Mixer',
  'A social mixer designed for adults to meet neighbors and make new connections. Hosted bar, light appetizers, and fun icebreaker activities.',
  'adults',
  CURRENT_DATE + INTERVAL '7 days',
  '7:30 PM',
  'Skyline Social Club',
  'https://images.pexels.com/photos/12645207/pexels-photo-12645207.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'Social',
  '$20 (includes 2 drinks)'
),
(
  'Outdoor Movie Night',
  'Bring a blanket and enjoy a classic film under the stars. Concessions available. BYOB friendly (canned beer & wine only). 18+ after 9 PM.',
  'adults',
  CURRENT_DATE + INTERVAL '8 days',
  '8:30 PM',
  'Greenfield Park — East Lawn',
  'https://images.pexels.com/photos/6173989/pexels-photo-6173989.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'Entertainment',
  'Free'
),
(
  'Weekend Brunch & Bloody Mary Bar',
  'Bottomless brunch with a build-your-own Bloody Mary station, live acoustic set, and chef specials. Reservations recommended.',
  'adults',
  CURRENT_DATE + INTERVAL '9 days',
  '10:00 AM',
  'The Neighborhood Kitchen',
  'https://images.pexels.com/photos/29786266/pexels-photo-29786266.jpeg?auto=compress&cs=tinysrgb&h=650&w=940',
  'Food & Drink',
  '$40 per person'
);
