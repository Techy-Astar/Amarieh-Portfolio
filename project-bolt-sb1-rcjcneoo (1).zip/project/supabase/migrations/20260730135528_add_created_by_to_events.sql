/*
# Add created_by column to events table

## Purpose
Track which profile created each event so the app can restrict deletion to the
event's creator. Previously every event was deletable by anyone.

## Modified Tables
### events
- Added `created_by` (uuid, nullable) — references profiles(id).
  Nullable because existing seed events were created by no one; new events
  created through the app will store the creator's profile id.
  ON DELETE SET NULL so deleting a profile doesn't destroy their events.

## Security
- No RLS policy changes. The events table remains publicly readable/writable
  via anon + authenticated (no-auth community app). Deletion ownership is
  enforced in the application layer by comparing created_by to the current
  profile id, since this app has no Supabase auth sessions (anon-key only).
- Existing seed events keep created_by = NULL, meaning no one can delete them
  through the UI — they are community-curated defaults.

## Notes
- Uses IF NOT EXISTS via DO block so re-running is safe.
- No data is lost: the column is nullable and added with no default.
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'events' AND column_name = 'created_by'
  ) THEN
    ALTER TABLE events ADD COLUMN created_by uuid REFERENCES profiles(id) ON DELETE SET NULL;
  END IF;
END $$;
